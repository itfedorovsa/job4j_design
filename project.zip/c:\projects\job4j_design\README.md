# job4j_design

This project applies:
 - Algorithms and data structures            
 - Input-Output                              
 - SQL, JDBC                              
 - Garbage Collection                      
 - Object-oriented design                 